angular.module('businessServ',[])

.factory('businessServ', function($http) {
    return {
    	ServiceProviderRegister:function(data){
    		return $http.post('/serviceprovider/register',data);


    	},

    	ServiceProviderLogin:function(data){
    	 return $http.post('/forbussinus/login',data);
    	 

    	}

    
    };
});