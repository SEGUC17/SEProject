angular.module('spAuthServ',[])

// .factory('spAuthServ', function($http) {
//     return {
    	
//     	}

    
//     };
// });